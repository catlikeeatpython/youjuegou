// import HelloWorld from '@/pages/HelloWorld'
// 路由的懒加载
const Home = () => import(/* webpackChunkName: "group-footer" */ '@/pages/Home')
const Kind = () => import(/* webpackChunkName: "group-footer" */ '@/pages/Kind')
const Cart = () => import(/* webpackChunkName: "group-footer" */ '@/pages/Cart')
const Users = () => import(/* webpackChunkName: "group-footer" */ '@/pages/Users')
const Detail = () => import(/* webpackChunkName: "group-nofooter" */ '@/pages/Detail')
const Register = () => import(/* webpackChunkName: "group-footer" */ '@/pages/Register')
const Footer = () => import(/* webpackChunkName: "group-footer" */ '@/components/Footer')

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'home',
    components: {
      // default: () => import(/* webpackChunkName: "group-footer" */ '@/pages/Home'),
      default: Home,
      footer: Footer
    },
    alias: '/h'
  },
  {
    path: '/kind',
    name: 'kind',
    components: {
      default: Kind,
      footer: Footer
    }
  },
  {
    path: '/cart',
    name: 'cart',
    components: {
      default: Cart,
      footer: Footer
    }
    // ,
    // beforeEnter (to, form, next) {
    //   if (localStorage.getItem('isLogin' === 'ok')) {
    //     next()
    //   } else {
    //     next('/register')
    //   }
    // }
  },
  {
    path: '/users',
    name: 'users',
    components: {
      default: Users,
      footer: Footer
    }
  },
  {
    path: '/city',
    name: 'city',
    components: {
      default: () => import(/* webpackChunkName: "group-footer" */ '@/pages/City'),
      footer: Footer
    }
  },
  {
    path: '/detail/:id',
    name: 'detail',
    component: Detail
  },
  {
    path: '/register',
    name: 'register',
    components: {
      default: Register
    }
  },
  {
    path: '/login',
    name: 'login',
    components: {
      default: () => import(/* webpackChunkName: "group-footer" */ '@/pages/Login')
    }
  }
]

export default routes
