<template>
  <van-notice-bar
  text="足协杯战线连续第2年上演广州德比战，上赛季半决赛上恒大以两回合5-3的总比分淘汰富力。"
  left-icon="volume-o"
/>
</template>
<script>
import Vue from 'vue'
import { NoticeBar } from 'vant'

Vue.use(NoticeBar)
export default {
  name: 'notice'
}
</script>
<style lang="scss">

</style>
