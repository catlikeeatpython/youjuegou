<template>
  <div class="cont">
    <ul>
      <li>
        <span><img src="/static/images/man.png" /></span>
        <p>男装</p>
      </li>
      <li>
        <span><img src="/static/images/women.png" /></span>
        <p>女装</p>
      </li>
      <li>
        <span><img src="/static/images/shoes.png" /></span>
        <p>鞋子</p>
      </li>
      <li>
        <span><img src="/static/images/muying.png" /></span>
        <p>母婴</p>
      </li>
    </ul>
    <ul>
      <li>
        <span><img src="/static/images/phone.png" /></span>
        <p>手机</p>
      </li>
      <li>
        <span><img src="/static/images/diannao.png" /></span>
        <p>电脑</p>
      </li>
      <li>
        <span><img src="/static/images/icon.png" /></span>
        <p>居家</p>
      </li>
      <li>
        <span><img src="/static/images/more.png" /></span>
        <p>更多</p>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'conts'
}
</script>
<style lang="scss">
@import '@/qunar/reset.scss';
.cont{
  @include flexbox();
  @include rect(100%,1.6rem);
  @include flex-direction(column);
  // @include background-color(rgb(51, 87, 167));
  ul{
    @include flexbox();
    @include rect(100%,100%);
    li{
      @include flex();
      @include rect(2rem,50%);
      @include flexbox();
      @include align-items();
      @include flex-direction(column);
      span{
        @include margin;
        @include padding;
      }
    }
  }
}
</style>
