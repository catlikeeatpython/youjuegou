<template>
  <div class="container">
    <van-nav-bar
      title="会员登录"
      right-text="去注册"
      @click-right="onClickRight"
      />
    <mt-field  placeholder="请输入用户名" type="text" v-model="username"></mt-field>
    <mt-field  placeholder="请输入密码" type="password" v-model="password"></mt-field>
    <mt-button type="primary" @click.native="loginin">登录</mt-button>
    <div>
       <span class="log_p_l">还没注册账号？<router-link to="/register" @click.native="onload">去注册</router-link></span>
      <span class="log_p_r"><router-link to='#'>忘记密码?</router-link></span>
    </div>
  </div>
</template>
<script>
import Vue from 'vue'
import { NavBar } from 'vant'
import { Field, Toast } from 'mint-ui'
import api from '@/api/login'

Vue.use(NavBar, Field)
export default {
  name: 'login',
  data () {
    return {
      username: '',
      password: ''
    }
  },
  methods: {
    onClickRight () {
      this.$router.push('/register')
      window.location.reload()
    },
    loginin () {
      api.requestList(this.username, this.password).then(data => {
        console.log(data)
        if (data.data === -1) {
          console.log('密码错误')
          let instance = Toast('密码错误')
          setTimeout(() => {
            instance.close()
          }, 2000)
        } else if (data.data === 0) {
          console.log('登录失败')
          let instance = Toast('登录失败')
          setTimeout(() => {
            instance.close()
          }, 2000)
        } else if (data.data === 2) {
          console.log('没有该用户')
          let instance = Toast('没有该用户')
          setTimeout(() => {
            instance.close()
          }, 2000)
        } else if (data.data === 1) {
          console.log('登陆成功')
          let instance = Toast('登陆成功')
          setTimeout(() => {
            instance.close()
            this.$router.push('/')
          }, 1000)
        }
      })
    }
  }
}
</script>
<style lang="scss">
html {
  font-size: 15.625vw;
}
.van-nav-bar {
  background: rgb(47, 144, 235);
  .van-nav-bar__title {
    color: rgb(21, 21, 145);
    font-weight: bold;
    font-size: 0.28rem;
  }
  .van-nav-bar__right{
    .van-nav-bar__text{
      font-size: 0.18rem;
      color: red;
    }
  }
}
.mint-cell{
  margin-top: 0.2rem;
  border: 0.01rem solid #ccc;
}
.mint-button {
  margin-top: 0.3rem;
}
.log_p_l {
  float: left;
  margin-top: 0.1rem;
  width: 3rem;
}
.log_p_r {
  float: right;
  margin-top: 0.1rem;
}
</style>
