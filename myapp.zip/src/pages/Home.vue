<template>
 <div class="container">
    <header class="header">
      <mt-header title="multiple button">
        <router-link to="/" slot="left">
          <mt-button @click.native="right_btn"><img src="/static/images/daoh.png" /></mt-button>
        </router-link>
        <mt-button icon="more" slot="right"></mt-button>
      </mt-header>
    </header>
    <div class="content">
      <mt-loadmore :top-method="loadTop" :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" ref="loadmore">
        <mt-swipe :auto="4000" class="mit-swipe">
          <mt-swipe-item v-for="(item, index) of Slide" :key="index">
            <img :src="item" alt="item">
          </mt-swipe-item>
        <!-- <mt-swipe-item>1</mt-swipe-item>
        <mt-swipe-item>1</mt-swipe-item>
        <mt-swipe-item>1</mt-swipe-item> -->
        </mt-swipe>
        <!-- 向List传数据-->
        <Cont />
        <Notice />
        <List :list="list" />
      </mt-loadmore>
      <mt-popup
        v-model="popupVisible"
        position="left">
        ...
      </mt-popup>
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import List from '@/components/home/List'
import Cont from '@/components/home/Cont'
import Notice from '@/components/home/Notice'
import api from '@/api/home'
import slideapi from '@/api/slide'
import { Swipe, SwipeItem, Loadmore, Toast, Header, Popup } from 'mint-ui'

// 使用ui库中的组件
Vue.use(Swipe, SwipeItem, Loadmore, Header, Popup)
export default {
  name: 'home',
  components: {
    List,
    Cont,
    Notice
  },
  data () {
    return {
      list: [],
      Slide: [],
      allLoaded: false, // 判断是否全部加载完毕
      pageCode: 0,
      popupVisible: false
    }
  },
  methods: {
    loadTop () { // 下拉刷新的函数实际上是请求列表第一页的数据
      api.requestList().then(data => {
        this.list = data
        this.pageCode = 1
        console.log(this)
        this.$refs.loadmore.onTopLoaded() // 更新列表的高度
        // console.log(data[0].title)
      }).catch(err => console.log(err))
    },
    loadBottom () {
      api.loadmore(this.pageCode).then(data => {
        if (data.length === 0) {
          this.allLoaded = true
          Toast({
            message: '加载完毕',
            position: 'bottom',
            duration: 5000
          })
        } else {
          // this.allLoaded = false
          this.list = [...this.list, ...data]
          this.pageCode += 1
        }
        this.$refs.loadmore.onBottomLoaded()
      })
      // this.allLoaded = true
    },
    right_btn () {
      this.popupVisible = true
    }
  },
  created () {
    api.requestList().then(data => {
      this.list = data
      console.log(this)
      // console.log(data[0].title)
    }).catch(err => console.log(err))
    slideapi.requestslide().then(data => {
      let arr = []
      for (var item of data) {
        arr.push('http:' + item.image)
        console.log('00000000000000000000000000000000000000000000')
        console.log('http:' + item.image)
      }
      this.Slide = arr
      console.log(this.Slide)
    }).catch(err => console.log(err))
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
@import '@/qunar/reset.scss';
.mit-swipe{
  @include rect(100%,1.6rem);
  img{
    @include rect(100%, auto);
  }
}

</style>
