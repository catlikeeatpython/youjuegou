<template>
 <div class="container">
    <header class="header">
      <div class="btn">
        <div @click="outuser">退出</div>
          <mt-actionsheet
            :actions="actions"
            v-model="sheetVisible">
          </mt-actionsheet>
      </div>
    </header>
    <div class="content">
      我的内容
    </div>
  </div>
</template>

<script>
import Vue from 'vue'
import { Actionsheet } from 'mint-ui'

Vue.use(Actionsheet)
export default {
  name: 'users',
  data () {
    return {
      actions: [
        {
          // name是表单上显示的文本
          name: '退出登录',
          // 可选）是单击时的回调
          method: this.fn1
        },
        {
          name: '放弃退出',
          method: this.fn2
        }
      ],
      sheetVisible: false
    }
  },
  methods: {
    outuser () {
      this.sheetVisible = true
    },
    fn1 () {
      console.log('退出登录')
    },
    fn2 () {
      console.log('放弃退出')
    }
    // selecActive () {
    //   this.sheetVisible = true
    // }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
@import '@/qunar/reset.scss';
.header{
  .btn{
    float: right;
  }
}
</style>
