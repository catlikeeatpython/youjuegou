<template>
  <div class="container">
    详情
    <Back />
    {{ pro.title }}
  </div>
</template>

<script>
import Back from '@/components/common/Back'
import api from '@/api/detail'
export default {
  name: 'detail',
  data () {
    return {
      pro: {}
    }
  },
  components: {
    Back
  },
  created () {
    console.log(this)
    // console.log(this.$route.params.id)
    // 用query传的值
    // console.log(this.$route.query.id)
    // const routeid = this.$route.query.id
    const routeid = this.$route.params.id
    api.requestData(routeid).then(data => {
      console.log(data)
      this.pro = data[0]
    }).catch(err => {
      console.log(err)
    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
