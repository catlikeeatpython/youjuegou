<template>
 <div class="container">
    <header class="header">
      分类头部
    </header>
    <div class="content">
      {{ msg }}
      {{ bannerdata }}
      {{ prolist }}
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
// import api from '@/api/kind'

export default {
  name: 'kind',
  computed: {
    msg () {
      return 'test'
    },
    // 通过计算属性传值
    // bannerdata () {
    //   console.log(1)
    //   return this.$store.state.KindStore.bannerdata
    // },
    // prolist () {
    //   return this.$store.state.KindStore.proList
    // }
    ...mapState({
      bannerdata: state => state.KindStore.bannerdata,
      prolist: state => state.KindStore.proList
    })
  },
  created () {
    // 通过this.$store.commit('mutationname', data)提交数据给/kind/index.js
    console.log(this)
    // api.requestData('https://www.daxunxun.com/banner').then(data => {
    //   this.$store.commit('changeBannerData', data)
    // }).catch(err => console.log(err))
    // api.requestData('https://www.daxunxun.com/douban').then(data => {
    //   this.$store.commit('changeproList', data)
    // }).catch(err => console.log(err))
    this.$store.dispatch('requestBanner')
    this.$store.dispatch('requestprolist')
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
