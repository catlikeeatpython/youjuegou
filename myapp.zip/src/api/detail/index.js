import axios from 'axios'
// 获取商品的详细信息
const api = {
  requestData (id) {
    return new Promise((resolve, reject) => {
      axios.get('https://www.daxunxun.com/detail?id=' + id).then(data => {
        console.log(data.data)
        resolve(data.data)
      }).catch(err => reject(err))
    })
  }
}

export default api
